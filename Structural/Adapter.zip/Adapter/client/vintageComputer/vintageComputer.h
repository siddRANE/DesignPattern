#pragma once
namespace vintage {
	class __declspec(dllexport) vintageComputer
	{
	public:
		void on();
		void off();
	};
}
