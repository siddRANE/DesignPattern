#include "ac.hxx"
#include <iostream>
void Products::ac::switchOn(bool arg)
{
	using namespace std;
	cout << __FUNCTION__ << "  " << arg << endl;
}
