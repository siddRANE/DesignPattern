#pragma once
namespace Products
{
	class electricEquipment
	{
	public:
		virtual void switchOn(bool) = 0;
	};
}